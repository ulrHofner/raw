# Table Plus для Superset 6.1

Копия стандартной таблицы (`plugin-chart-table` из 6.1.0) с двумя изменениями:

- столбцы, которых нет в результате датасета, скрываются вместо ошибки БД;
- под шапкой есть строка фильтрации с уникальными значениями столбца при текущих фильтрах.

## Сборка

```bash
npm install
npm run build
```

Результат: `dist/table-plus.js`, один файл до 1 МиБ, он помещается в ConfigMap.

## Установка

1. Создать ConfigMap `superset-plugin-table-plus` с файлом `table-plus.js` в namespace Superset.
2. Добавить `deploy/superset-values.table-plus.yaml` вторым `--values` в `helm upgrade`.
3. На `/dynamic-plugins/list/` добавить запись:
   Name `Table Plus`, Key `table_plus`, Bundle URL `/static/assets/plugins/table-plus.js?v=1`.

Key обязан совпадать с `viz_type`. Подсказка в форме про имя пакета неверна: Explore ищет
плагин именно по `viz_type`.

## Обновление бандла

Статика кэшируется браузером на год, поэтому после пересоздания ConfigMap и рестарта подов
увеличьте `?v=` в Bundle URL.

## Как это устроено

- `src/liveQuery.ts` проверяет столбцы до основного запроса и загружает значения фильтров.
- `src/filterRow/ColumnFilter.tsx` рисует ячейку фильтра.
- `src/shims/` заменяет модули, которых нет в shared-модулях Superset.
- `src/recoverLateExplore.ts` перезагружает Explore, если бандл пришёл позже его данных.
