import { useMemo } from 'react';
import { ThemeProvider } from '@emotion/react';
import { ConfigProvider } from 'antd';
import TableChart from './TableChart';

// antd и emotion в бандле свои, контексты Superset до них не доходят.
// Тема приходит из chartProps, поэтому таблица выглядит как остальные графики.
export default function TablePlusChart(props: any) {
  const { theme } = props;
  const antdTheme = useMemo(
    () => ({
      token: Object.fromEntries(
        Object.entries(theme).filter(([, value]) =>
          ['string', 'number'].includes(typeof value),
        ),
      ),
    }),
    [theme],
  );
  return (
    <ThemeProvider theme={theme}>
      <ConfigProvider theme={antdTheme}>
        <TableChart {...props} />
      </ConfigProvider>
    </ThemeProvider>
  );
}
