import { useMemo, useRef, useState } from 'react';
import { styled } from '@apache-superset/core/theme';
import { t } from '@apache-superset/core/translation';
import { Button, Checkbox, Input, Popover, Spin, Tooltip } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import VirtualList from 'rc-virtual-list';
import type { FilterValue } from '../liveQuery';

const LIST_HEIGHT = 240;
const ROW_HEIGHT = 28;

type LoadResult = {
  values: FilterValue[];
  truncated: boolean;
  failed?: boolean;
};

type Props = {
  selected: FilterValue[];
  disabledReason?: string;
  limit: number;
  load: () => Promise<LoadResult>;
  format: (value: FilterValue) => string;
  onChange: (values: FilterValue[]) => void;
};

/** Ключ с типом: 1 и "1", null и "null" должны оставаться разными значениями. */
export function filterValueKey(value: unknown) {
  const raw = value instanceof Date ? value.getTime() : value;
  return `${raw === null ? 'null' : typeof raw}:${String(raw)}`;
}

function compareValues(a: FilterValue, b: FilterValue) {
  if (a === null) return b === null ? 0 : 1;
  if (b === null) return -1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b), undefined, { numeric: true });
}

const Trigger = styled.button<{ active: boolean }>`
  ${({ theme, active }) => `
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: ${theme.sizeUnit}px;
    width: 100%;
    height: ${theme.sizeUnit * 6}px;
    padding: 0 ${theme.sizeUnit}px;
    overflow: hidden;
    color: ${active ? theme.colorPrimary : theme.colorTextTertiary};
    font-size: ${theme.fontSizeSM}px;
    font-weight: ${theme.fontWeightNormal};
    background: ${theme.colorBgContainer};
    border: 1px solid ${active ? theme.colorPrimary : theme.colorBorder};
    border-radius: ${theme.borderRadius}px;
    cursor: pointer;

    &:hover:not(:disabled) {
      border-color: ${theme.colorPrimary};
    }

    &:disabled {
      cursor: not-allowed;
      background: ${theme.colorBgLayout};
    }

    & > span:first-of-type {
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    & svg {
      flex-shrink: 0;
      margin: 0;
      font-size: ${theme.fontSizeXS ?? theme.fontSizeSM}px;
      fill-opacity: 0.6;
    }
  `}
`;

const Panel = styled.div`
  ${({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: ${theme.sizeUnit * 2}px;
    width: ${theme.sizeUnit * 64}px;

    .dt-filter-actions {
      display: flex;
      justify-content: space-between;
    }

    .dt-filter-note {
      color: ${theme.colorTextTertiary};
      font-size: ${theme.fontSizeSM}px;
    }

    .dt-filter-empty {
      padding: ${theme.sizeUnit * 4}px 0;
      color: ${theme.colorTextTertiary};
      text-align: center;
    }

    .dt-filter-option {
      display: flex;
      align-items: center;
      height: ${ROW_HEIGHT}px;
      overflow: hidden;
      white-space: nowrap;
    }

    .dt-filter-option .ant-checkbox-wrapper {
      width: 100%;
      min-width: 0;
    }

    .dt-filter-option .ant-checkbox + span {
      overflow: hidden;
      text-overflow: ellipsis;
    }
  `}
`;

export default function ColumnFilter({
  selected,
  disabledReason,
  limit,
  load,
  format,
  onChange,
}: Props) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<LoadResult>({
    values: [],
    truncated: false,
  });
  const [draft, setDraft] = useState(selected);
  const [search, setSearch] = useState('');
  const lastRequest = useRef(0);

  const draftKeys = useMemo(() => new Set(draft.map(filterValueKey)), [draft]);

  const options = useMemo(() => {
    // выбранное значение могло выпасть из вариантов после смены других фильтров,
    // но снять его всё равно должно быть можно
    const unique = new Map(
      [...result.values, ...selected].map(value => [
        filterValueKey(value),
        value,
      ]),
    );
    const needle = search.trim().toLowerCase();
    return [...unique.entries()]
      .sort(([, a], [, b]) => compareValues(a, b))
      .map(([key, value]) => ({ key, value, label: format(value) }))
      .filter(
        option => !needle || option.label.toLowerCase().includes(needle),
      );
  }, [format, result.values, search, selected]);

  const fetchValues = async () => {
    const request = lastRequest.current + 1;
    lastRequest.current = request;
    setLoading(true);
    const next = await load();
    if (lastRequest.current === request) {
      setResult(next);
      setLoading(false);
    }
  };

  const commit = (values: FilterValue[]) => {
    const unchanged =
      values.length === selected.length &&
      values.every(value =>
        selected.some(item => filterValueKey(item) === filterValueKey(value)),
      );
    if (!unchanged) onChange(values);
  };

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      setDraft(selected);
      setSearch('');
      fetchValues();
    } else {
      commit(draft);
    }
  };

  const toggle = (value: FilterValue) => {
    const key = filterValueKey(value);
    setDraft(current =>
      current.some(item => filterValueKey(item) === key)
        ? current.filter(item => filterValueKey(item) !== key)
        : [...current, value],
    );
  };

  const selectVisible = () => {
    setDraft(current => [
      ...current,
      ...options
        .filter(option => !draftKeys.has(option.key))
        .map(option => option.value),
    ]);
  };

  const close = (values: FilterValue[]) => {
    setOpen(false);
    commit(values);
  };

  let triggerText = t('All');
  if (selected.length === 1) triggerText = format(selected[0]);
  if (selected.length > 1) triggerText = t('%s selected', selected.length);

  const trigger = (
    <Trigger
      type="button"
      active={selected.length > 0}
      disabled={Boolean(disabledReason)}
      title={selected.map(format).join(', ') || undefined}
    >
      <span>{triggerText}</span>
      <DownOutlined />
    </Trigger>
  );

  if (disabledReason) {
    return <Tooltip title={disabledReason}>{trigger}</Tooltip>;
  }

  const content = (
    <Panel>
      <Input
        size="small"
        allowClear
        autoFocus
        placeholder={t('Search')}
        value={search}
        onChange={event => setSearch(event.target.value)}
      />
      <div className="dt-filter-actions">
        <Button size="small" type="link" onClick={selectVisible}>
          {t('Select all')}
        </Button>
        <Button size="small" type="link" onClick={() => setDraft([])}>
          {t('Clear')}
        </Button>
      </div>
      <Spin spinning={loading}>
        {options.length > 0 ? (
          <VirtualList
            data={options}
            height={LIST_HEIGHT}
            fullHeight={false}
            itemHeight={ROW_HEIGHT}
            itemKey="key"
          >
            {option => (
              <div className="dt-filter-option" title={option.label}>
                <Checkbox
                  checked={draftKeys.has(option.key)}
                  onChange={() => toggle(option.value)}
                >
                  {option.label}
                </Checkbox>
              </div>
            )}
          </VirtualList>
        ) : (
          <div className="dt-filter-empty">{t('No values')}</div>
        )}
      </Spin>
      {result.truncated && (
        <div className="dt-filter-note">
          {t('Showing the first %s values', limit)}
        </div>
      )}
      {result.failed && (
        <div className="dt-filter-note">
          {t('Values could not be loaded, showing the current rows only')}
        </div>
      )}
      <Button size="small" type="primary" block onClick={() => close(draft)}>
        {t('Apply')}
      </Button>
    </Panel>
  );

  return (
    <Popover
      open={open}
      onOpenChange={handleOpenChange}
      trigger="click"
      placement="bottomLeft"
      arrow={false}
      destroyOnHidden
      content={content}
    >
      {trigger}
    </Popover>
  );
}
