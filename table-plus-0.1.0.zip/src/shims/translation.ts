// Переводчик Superset живёт в неразделяемом @apache-superset/core, поэтому плагин
// поднимает свой экземпляр на том же language pack.
import Jed from 'jed';

const RU: Record<string, string> = {
  'Table Plus': 'Таблица Плюс',
  'The default table with a filter row and automatic hiding of columns that are missing from the query result.':
    'Стандартная таблица со строкой фильтрации и автоматическим скрытием столбцов, которых нет в результате запроса.',
  'Show filter row': 'Показывать строку фильтрации',
  'Adds a row under the header. Each column offers its unique values for the current filters.':
    'Добавляет строку под шапкой. Для каждого столбца доступны его уникальные значения с учётом текущих фильтров.',
  'Filter values limit': 'Лимит значений в фильтре',
  'Maximum number of unique values loaded for one column.':
    'Сколько уникальных значений столбца загружать максимум.',
  'Hide missing columns': 'Скрывать отсутствующие столбцы',
  'Before each query, checks which columns the dataset returns for the current filters and drops the rest instead of failing. Adds a LIMIT 1 query per chart load.':
    'Перед запросом проверяет, какие столбцы датасет отдаёт при текущих фильтрах, и убирает остальные вместо ошибки. Добавляет запрос с LIMIT 1 на каждую загрузку графика.',
  All: 'Все',
  Search: 'Поиск',
  'Select all': 'Выбрать все',
  Clear: 'Очистить',
  Apply: 'Применить',
  '%s selected': 'Выбрано: %s',
  'No values': 'Нет значений',
  'Showing the first %s values': 'Показаны первые %s значений',
  'Values could not be loaded, showing the current rows only':
    'Не удалось загрузить значения, показаны только текущие строки',
  'Metric columns cannot be filtered with server pagination':
    'С серверной пагинацией столбцы метрик не фильтруются',
};

const EMPTY_PACK = {
  domain: 'superset',
  locale_data: {
    superset: {
      '': {
        domain: 'superset',
        lang: 'en',
        plural_forms: 'nplurals=2; plural=(n != 1)',
      },
    },
  },
};

function readLocale(): string {
  try {
    const raw = document.getElementById('app')?.getAttribute('data-bootstrap');
    return (raw && JSON.parse(raw)?.common?.locale) || 'en';
  } catch {
    return 'en';
  }
}

// Superset 6.1 грузит language pack отдельным запросом. Здесь он нужен до импорта
// контролов, а асинхронная загрузка отодвинула бы регистрацию плагина за момент,
// когда Explore строит контролы. Поэтому запрос синхронный, ответ берётся из кэша.
function loadLanguagePack(language: string) {
  if (language === 'en') return EMPTY_PACK;
  try {
    const request = new XMLHttpRequest();
    request.open('GET', `/superset/language_pack/${language}/`, false);
    request.send();
    const languagePack = JSON.parse(request.responseText);
    return languagePack?.locale_data?.superset ? languagePack : EMPTY_PACK;
  } catch {
    return EMPTY_PACK;
  }
}

const locale = readLocale();
const pack: any = loadLanguagePack(locale);
if (locale.startsWith('ru')) {
  Object.entries(RU).forEach(([key, value]) => {
    pack.locale_data.superset[key] = [value];
  });
}
const i18n = new (Jed as any)(pack);

export function t(input: string, ...args: unknown[]): string {
  try {
    return i18n.translate(input).fetch(...args);
  } catch {
    return input;
  }
}

export function tn(key: string, ...args: unknown[]): string {
  try {
    const [plural, num, ...rest] = args;
    if (typeof plural === 'number') {
      return i18n.translate(key).ifPlural(plural, key).fetch(plural, num, ...rest);
    }
    return i18n
      .translate(key)
      .ifPlural(num as number, plural as string)
      .fetch(...rest);
  } catch {
    return key;
  }
}
