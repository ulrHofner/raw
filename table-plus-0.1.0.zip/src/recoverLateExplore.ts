/**
 * Explore строит контролы сразу после ответа /api/v1/explore/. Если бандл пришёл
 * позже (обычно это первый заход с пустым кэшем), контролы остаются пустыми, а
 * штатное восстановление Superset теряет form_data. Бандл к этому моменту уже в
 * кэше браузера, поэтому одной перезагрузки достаточно.
 */
const STORAGE_KEY = 'table-plus-late-reload';
const RELOAD_INTERVAL_MS = 30_000;

export default async function recoverLateExplore(vizType: string) {
  const [explore] = performance
    .getEntriesByType('resource')
    .filter(entry => entry.name.includes('/api/v1/explore/'));
  if (!explore) return;
  try {
    const lastReload = Number(sessionStorage.getItem(STORAGE_KEY));
    if (Date.now() - lastReload < RELOAD_INTERVAL_MS) return;
    const response = await fetch(explore.name, { credentials: 'same-origin' });
    const { result } = await response.json();
    if (result?.form_data?.viz_type !== vizType) return;
    sessionStorage.setItem(STORAGE_KEY, String(Date.now()));
    window.location.reload();
  } catch {
    // без sessionStorage или при сбое сети страницу обновит сам пользователь
  }
}
