/**
 * Запросы таблицы с учётом столбцов, которых может не быть в датасете.
 *
 * Виртуальный датасет с Jinja меняет набор столбцов в зависимости от фильтров.
 * Superset оборачивает его в подзапрос, поэтому SELECT по пропавшему столбцу
 * падает ошибкой БД и компонент графика не рендерится вовсе. Ошибку нельзя
 * поймать после запроса, зато buildQuery в Superset ожидается через await: здесь
 * до основного запроса проверяется, какие столбцы живы, и лишние убираются.
 */
import {
  SupersetClient,
  ensureIsArray,
  getColumnLabel,
  getMetricLabel,
  isPhysicalColumn,
  QueryMode,
} from '@superset-ui/core';
import { isEqual, omit, uniqBy } from 'lodash';

export type FilterValue = string | number | boolean | null;
export type ColumnFilters = Record<string, FilterValue[]>;

type Json = Record<string, any>;
type Options = { ownState?: Json; hooks?: Json; extras?: Json };
type Build = (formData: Json, options: Options) => Json;
type Item = {
  id: string;
  name: string;
  kind: 'column' | 'metric';
  probe: { column?: any; metric?: any };
};
type Verdict = { missing: Item[]; pruneFilters: boolean };

const NOTHING_MISSING: Verdict = { missing: [], pruneFilters: false };
const VERDICT_TTL_MS = 60_000;
const verdicts = new Map<string, { at: number; verdict: Promise<Verdict> }>();

class Inconclusive extends Error {}

const noop = () => {};

function getMode(formData: Json) {
  const { query_mode: mode, all_columns: rawColumns } = formData;
  if (mode === QueryMode.Aggregate || mode === QueryMode.Raw) {
    return mode;
  }
  return rawColumns?.length ? QueryMode.Raw : QueryMode.Aggregate;
}

function sourceColumns(formData: Json): any[] {
  return ensureIsArray(
    getMode(formData) === QueryMode.Raw
      ? formData.all_columns
      : formData.groupby,
  );
}

/** Гранулярность времени таблица применяет только к первому временному столбцу. */
function baseAxisGrain(formData: Json, key: string) {
  if (getMode(formData) !== QueryMode.Aggregate) return undefined;
  const grain =
    formData.extra_form_data?.time_grain_sqla || formData.time_grain_sqla;
  const lookup = formData.temporal_columns_lookup;
  const baseAxis = sourceColumns(formData).find(
    col => isPhysicalColumn(col) && lookup?.[col],
  );
  return grain && baseAxis === key ? grain : undefined;
}

function toClause(formData: Json, key: string, val: FilterValue[]) {
  const col =
    sourceColumns(formData).find(item => getColumnLabel(item) === key) ?? key;
  const grain = baseAxisGrain(formData, key);
  return { col, op: 'IN', val, ...(grain ? { grain } : {}) };
}

function activeFilters(ownState?: Json): [string, FilterValue[]][] {
  return Object.entries<FilterValue[]>(ownState?.columnFilters ?? {}).filter(
    ([, values]) => values?.length > 0,
  );
}

/** Выбор в строке фильтрации идёт тем же путём, что и фильтры дашборда. */
function withColumnFilters(formData: Json, ownState?: Json) {
  const clauses = activeFilters(ownState).map(([key, values]) =>
    toClause(formData, key, values),
  );
  if (!clauses.length) return formData;
  return {
    ...formData,
    extra_form_data: {
      ...formData.extra_form_data,
      filters: [
        ...ensureIsArray(formData.extra_form_data?.filters),
        ...clauses,
      ],
    },
  };
}

function columnItem(column: any): Item {
  const name = getColumnLabel(column);
  return { id: `column:${name}`, name, kind: 'column', probe: { column } };
}

function metricItem(metric: any): Item {
  const name = getMetricLabel(metric);
  const simpleColumn =
    metric?.expressionType === 'SIMPLE' ? metric.column?.column_name : undefined;
  return {
    id: `metric:${name}`,
    name,
    kind: 'metric',
    // столбец проверяется без агрегации: так дешевле, чем считать саму метрику
    probe: simpleColumn ? { column: simpleColumn } : { metric },
  };
}

function orderByColumns(formData: Json): string[] {
  return ensureIsArray(formData.order_by_cols).flatMap((raw: string) => {
    try {
      return [JSON.parse(raw)[0]];
    } catch {
      return [];
    }
  });
}

function collectItems(formData: Json): Item[] {
  const isAggregate = getMode(formData) === QueryMode.Aggregate;
  const columns = [
    ...sourceColumns(formData),
    ...(isAggregate ? [] : orderByColumns(formData)),
  ];
  const metrics = isAggregate
    ? [
        ...ensureIsArray(formData.metrics),
        ...ensureIsArray(formData.percent_metrics),
        ...ensureIsArray(formData.timeseries_limit_metric),
      ]
    : [];
  return uniqBy(
    [...columns.map(columnItem), ...metrics.map(metricItem)],
    item => item.id,
  );
}

function filterItems(context: Json): Item[] {
  return ensureIsArray(context.queries[0].filters)
    .filter((filter: Json) => filter.col)
    .map((filter: Json) => columnItem(filter.col));
}

const PROBE_OVERRIDES = {
  orderby: [],
  post_processing: [],
  time_offsets: [],
  annotation_layers: [],
  row_limit: 1,
  row_offset: 0,
  is_rowcount: false,
  is_timeseries: false,
};

/**
 * Jinja (filter_values, get_filters) читает фильтры из сырого JSON первого запроса.
 * Ключ extra_filters схема запроса отбрасывает, а Jinja видит: состав столбцов
 * остаётся прежним, хотя в WHERE фильтр не попадает. Adhoc-столбцы сюда нельзя:
 * merge_extra_filters использует col как ключ словаря.
 */
function jinjaOnlyFilters(filters: Json[]) {
  return filters.filter(filter => typeof filter.col === 'string');
}

function probeContext(context: Json, items: Item[], keepFilters: boolean) {
  const [first] = context.queries;
  const base: Json = { ...first, ...PROBE_OVERRIDES };
  if (!keepFilters) {
    base.filters = [];
    base.extra_filters = jinjaOnlyFilters(ensureIsArray(first.filters));
    base.extras = omit(first.extras, ['where', 'having']);
    delete base.granularity;
  }
  const columns = uniqBy(
    items.flatMap(item => (item.probe.column ? [item.probe.column] : [])),
    getColumnLabel,
  );
  const metrics = items.flatMap(item =>
    item.probe.metric ? [item.probe.metric] : [],
  );
  const queries = [
    ...(columns.length ? [{ ...base, columns, metrics: undefined }] : []),
    ...(metrics.length ? [{ ...base, columns: [], metrics }] : []),
  ];
  return { ...context, queries, result_format: 'json', result_type: 'full' };
}

function dataEndpoint(formData: Json) {
  const params = new URLSearchParams();
  if (formData.slice_id !== undefined) {
    params.set('form_data', JSON.stringify({ slice_id: formData.slice_id }));
  }
  if (formData.dashboardId !== undefined) {
    params.set('dashboard_id', String(formData.dashboardId));
  }
  const query = params.toString();
  return `/api/v1/chart/data${query ? `?${query}` : ''}`;
}

async function passes(context: Json) {
  try {
    await SupersetClient.post({
      endpoint: dataEndpoint(context.form_data ?? {}),
      jsonPayload: context,
    } as any);
    return true;
  } catch (error: any) {
    // 400 — ошибка самого запроса. Всё остальное (сеть, 401/403, 5xx, таймаут)
    // ничего не говорит о столбцах, и убирать их на этом основании нельзя.
    if (error?.status === 400 || error?.status === 422) return false;
    throw new Inconclusive();
  }
}

/** Бинарный поиск: число проверок растёт с числом пропавших столбцов, а не всех. */
async function findBroken(
  items: Item[],
  isValid: (subset: Item[]) => Promise<boolean>,
  knownBroken = false,
): Promise<Item[]> {
  if (!knownBroken && (await isValid(items))) return [];
  if (items.length === 1) return items;
  const middle = Math.ceil(items.length / 2);
  const left = await findBroken(items.slice(0, middle), isValid);
  const right = await findBroken(
    items.slice(middle),
    isValid,
    left.length === 0,
  );
  return [...left, ...right];
}

function prune(
  formData: Json,
  ownState: Json | undefined,
  { missing, pruneFilters }: Verdict,
) {
  const columns = new Set(
    missing.filter(item => item.kind === 'column').map(item => item.name),
  );
  const metrics = new Set(
    missing.filter(item => item.kind === 'metric').map(item => item.name),
  );
  const keepColumn = (column: any) => !columns.has(getColumnLabel(column));
  const keepMetric = (metric: any) => !metrics.has(getMetricLabel(metric));

  const pruned: Json = {
    ...formData,
    all_columns: ensureIsArray(formData.all_columns).filter(keepColumn),
    groupby: ensureIsArray(formData.groupby).filter(keepColumn),
    metrics: ensureIsArray(formData.metrics).filter(keepMetric),
    percent_metrics: ensureIsArray(formData.percent_metrics).filter(keepMetric),
    order_by_cols: ensureIsArray(formData.order_by_cols).filter(
      (raw: string) => {
        try {
          return !columns.has(JSON.parse(raw)[0]);
        } catch {
          return true;
        }
      },
    ),
  };
  const sortMetric = ensureIsArray(formData.timeseries_limit_metric)[0];
  if (sortMetric && !keepMetric(sortMetric)) {
    pruned.timeseries_limit_metric = null;
  }

  const prunedOwnState: Json = { ...ownState };
  if (ownState?.sortBy) {
    prunedOwnState.sortBy = ensureIsArray(ownState.sortBy).filter(
      (sort: Json) => !columns.has(sort?.key),
    );
  }
  if (columns.has(ownState?.searchColumn)) {
    delete prunedOwnState.searchColumn;
    delete prunedOwnState.searchText;
  }

  if (pruneFilters) {
    const keepAdhoc = (filter: Json) =>
      !(filter.expressionType === 'SIMPLE' && columns.has(filter.subject));
    const extra = formData.extra_form_data;
    pruned.adhoc_filters = ensureIsArray(formData.adhoc_filters).filter(
      keepAdhoc,
    );
    pruned.extra_form_data = {
      ...extra,
      filters: ensureIsArray(extra?.filters).filter((filter: Json) =>
        keepColumn(filter.col),
      ),
      adhoc_filters: ensureIsArray(extra?.adhoc_filters).filter(keepAdhoc),
    };
  }
  return { formData: pruned, ownState: prunedOwnState };
}

async function detect(
  formData: Json,
  options: Options,
  base: Json,
  items: Item[],
  build: Build,
): Promise<Verdict> {
  if (await passes(probeContext(base, items, true))) return NOTHING_MISSING;

  // Фильтр по пропавшему столбцу ломает всё, поэтому ищем без WHERE.
  const candidates = uniqBy([...items, ...filterItems(base)], item => item.id);
  const missing = await findBroken(candidates, subset =>
    passes(probeContext(base, subset, false)),
  );
  const remaining = items.filter(item => !missing.includes(item));
  // Если не выжил ни один столбец, дело не в них: пусть покажется ошибка Superset.
  if (!missing.length || !remaining.length) return NOTHING_MISSING;

  // Фильтр мог снять сам Jinja (remove_filter=True), и тогда он нужен шаблону.
  const verdict = { missing, pruneFilters: false };
  const next = prune(formData, options.ownState, verdict);
  const candidate = build(next.formData, { ...options, ownState: next.ownState });
  return (await passes(probeContext(candidate, remaining, true)))
    ? verdict
    : { missing, pruneFilters: true };
}

function getVerdict(
  formData: Json,
  options: Options,
  base: Json,
  build: Build,
): Promise<Verdict> {
  const items = collectItems(formData);
  if (!items.length) return Promise.resolve(NOTHING_MISSING);

  const key = JSON.stringify([
    base.datasource,
    probeContext(base, items, true).queries,
  ]);
  const cached = verdicts.get(key);
  if (cached && !formData.force && Date.now() - cached.at < VERDICT_TTL_MS) {
    return cached.verdict;
  }
  const verdict = detect(formData, options, base, items, build).catch(error => {
    verdicts.delete(key);
    if (error instanceof Inconclusive) return NOTHING_MISSING;
    throw error;
  });
  verdicts.set(key, { at: Date.now(), verdict });
  return verdict;
}

function plainBuilder(buildTableQuery: Build): Build {
  return (formData, options) =>
    buildTableQuery(formData, {
      ...options,
      hooks: { ...options.hooks, setDataMask: noop, setCachedChanges: noop },
    });
}

/** Контекст запроса без столбцов, которых сейчас нет в датасете. */
async function resolve(
  formData: Json,
  options: Options,
  build: Build,
  buildFinal: Build,
) {
  const effective = withColumnFilters(formData, options.ownState);
  if (formData.hide_missing_columns === false) {
    return buildFinal(effective, options);
  }
  const base = build(effective, options);
  const verdict = await getVerdict(effective, options, base, build);
  if (!verdict.missing.length) return buildFinal(effective, options);
  const next = prune(effective, options.ownState, verdict);
  return buildFinal(next.formData, { ...options, ownState: next.ownState });
}

/**
 * SuperChart показывает «нет данных» вместо графика, если первые
 * queryObjectCount запросов пусты, и строка фильтрации исчезала бы вместе с
 * выбором, который её опустошил. Запрос rowcount всегда возвращает строку.
 */
function keepChartOnEmptyResult(context: Json, formData: Json, ownState?: Json) {
  const isChartRequest =
    context.result_format === 'json' && context.result_type === 'full';
  if (
    !isChartRequest ||
    context.queries.length !== 1 ||
    !activeFilters(ownState).length
  ) {
    return context;
  }
  const [first] = context.queries;
  return {
    ...context,
    queries: [
      first,
      {
        ...first,
        time_offsets: [],
        post_processing: [],
        orderby: [],
        row_limit: Number(formData.row_limit ?? 0),
        row_offset: 0,
        is_rowcount: true,
      },
    ],
  };
}

export function createBuildQuery(buildTableQuery: Build, cachedBuild: Build) {
  const build = plainBuilder(buildTableQuery);

  const buildQuery = async (formData: Json, options: Options = {}) => {
    const context = await resolve(formData, options, build, cachedBuild);
    return keepChartOnEmptyResult(context, formData, options.ownState);
  };

  /** Уникальные значения столбца при всех фильтрах, кроме его собственного. */
  const fetchColumnValues = async ({
    formData,
    ownState,
    columnKey,
    limit,
  }: {
    formData: Json;
    ownState?: Json;
    columnKey: string;
    limit: number;
  }) => {
    const context = await resolve(
      { ...formData, force: false, result_format: 'json', result_type: 'full' },
      { ownState },
      build,
      build,
    );
    const [first] = context.queries;
    const selected = ownState?.columnFilters?.[columnKey];
    const own = selected?.length
      ? toClause(formData, columnKey, selected)
      : undefined;
    const isOwn = (filter: Json) =>
      own !== undefined &&
      isEqual(filter.col, own.col) &&
      filter.op === own.op &&
      isEqual(filter.val, own.val);
    const column =
      ensureIsArray(first.columns).find(
        (item: any) => getColumnLabel(item) === columnKey,
      ) ?? columnKey;

    const { json } = await SupersetClient.post({
      endpoint: dataEndpoint(context.form_data ?? {}),
      jsonPayload: {
        ...context,
        force: false,
        queries: [
          {
            ...first,
            ...PROBE_OVERRIDES,
            ...(own ? { extra_filters: jinjaOnlyFilters([own]) } : {}),
            filters: ensureIsArray(first.filters).filter(
              (filter: Json) => !isOwn(filter),
            ),
            columns: [column],
            // пустой список метрик включает GROUP BY, то есть DISTINCT по столбцу
            metrics: [],
            orderby: typeof column === 'string' ? [[column, true]] : [],
            row_limit: limit + 1,
          },
        ],
        result_format: 'json',
        result_type: 'full',
      },
    } as any);
    const rows: Json[] = json?.result?.[0]?.data ?? [];
    return {
      values: rows.slice(0, limit).map(row => row[columnKey] as FilterValue),
      truncated: rows.length > limit,
    };
  };

  return { buildQuery, fetchColumnValues };
}
