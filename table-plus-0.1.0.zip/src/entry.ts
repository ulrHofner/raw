// react-table обращается к глобальному regeneratorRuntime
import 'regenerator-runtime/runtime';
import TablePlusChartPlugin from './index';
import recoverLateExplore from './recoverLateExplore';

// viz_type новых графиков. Менять нельзя: сохранённые графики ссылаются на него,
// а запись в /dynamic-plugins/list/ должна иметь такой же Key.
const VIZ_TYPE = 'table_plus';

new TablePlusChartPlugin().configure({ key: VIZ_TYPE }).register();
recoverLateExplore(VIZ_TYPE);
