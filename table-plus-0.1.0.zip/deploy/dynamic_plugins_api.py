# Superset 6.1 ждёт GET /dynamic-plugins/api/read, но в Flask-AppBuilder 5 этого
# маршрута больше нет: фронтенд получает 404 и не грузит ни один плагин.
# Запись отдаёт только то, что и так видно в браузере: имя, ключ и адрес бандла.
def FLASK_APP_MUTATOR(app):
    from flask import jsonify

    def read_dynamic_plugins():
        from superset import db, is_feature_enabled
        from superset.models.dynamic_plugins import DynamicPlugin

        if not is_feature_enabled("DYNAMIC_PLUGINS"):
            return jsonify({"result": []})
        return jsonify(
            {
                "result": [
                    {
                        "id": plugin.id,
                        "name": plugin.name,
                        "key": plugin.key,
                        "bundle_url": plugin.bundle_url,
                    }
                    for plugin in db.session.query(DynamicPlugin).all()
                ]
            }
        )

    app.add_url_rule(
        "/dynamic-plugins/api/read",
        endpoint="dynamic_plugins_api_read",
        view_func=read_dynamic_plugins,
    )
