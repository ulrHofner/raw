// Собирает один файл dist/table-plus.js для DYNAMIC_PLUGINS.
// react, react-dom, lodash и @superset-ui/* берутся у самого Superset через
// window['__superset__/<пакет>'], иначе реестры графиков будут чужими.
import { build } from 'esbuild';
import { resolve } from 'node:path';

const shim = name => resolve('src/shims', name);
const shared = /^(react|react-dom|lodash|@superset-ui\/core|@superset-ui\/chart-controls)$/;

const sharedModules = {
  name: 'superset-shared-modules',
  setup(b) {
    b.onResolve({ filter: shared }, args => ({ path: args.path, namespace: 'superset-shared' }));
    b.onLoad({ filter: /.*/, namespace: 'superset-shared' }, args => ({
      contents: `module.exports = window[${JSON.stringify(`__superset__/${args.path}`)}];`,
      loader: 'js',
    }));
  },
};

await build({
  entryPoints: ['src/entry.ts'],
  outfile: 'dist/table-plus.js',
  bundle: true,
  format: 'iife',
  platform: 'browser',
  target: 'es2019',
  minify: true,
  legalComments: 'none',
  metafile: true,
  jsx: 'automatic',
  jsxImportSource: '@emotion/react',
  define: { 'process.env.NODE_ENV': '"production"', 'process.env.WEBPACK_MODE': '"production"' },
  loader: { '.png': 'dataurl' },
  alias: {
    '@apache-superset/core/theme': shim('theme.ts'),
    '@apache-superset/core/translation': shim('translation.ts'),
    '@apache-superset/core/common': shim('common.ts'),
    '@superset-ui/core/components': shim('components.ts'),
  },
  plugins: [sharedModules],
}).then(({ metafile }) => {
  const { bytes } = metafile.outputs['dist/table-plus.js'];
  console.log(`dist/table-plus.js ${(bytes / 1024).toFixed(0)} KiB`);
});
